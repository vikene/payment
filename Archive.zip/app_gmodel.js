import {MongoClient, ObjectID} from 'mongodb'
import {makeExecutableSchema} from 'graphql-tools'
import {graphiqlExpress, graphqlExpress} from 'graphql-server-express'
import express from 'express';
import * as bodyParser from 'body-parser';

export const start = async () => {
    try{
        const MONGOURL = "mongodb://localhost:27017/blog"
        const db = await MongoClient.connect(MONGOURL)
        const user = db.collection("User")
        const friend= db.collection("Friend")
        const wallet = db.collection("Wallet")
        const transaction = db.collection("Transaction")
        const prepare = (o) => {
            if(o != null){
                o._id = o._id.toString()
            }
            
            return o
        }
        const typeDefs = [`
            type User{
                _id: String,
                username: String,
                email: String,
                ssn: String,
                fname: String,
                lname: String,
                password: String,
                wallet: Wallet,
                walletId: String,
                transactions: [Transaction],
                friends: [Friend]
            }
            type Friend{
                _id: String,
                username: String,
                friendusername: String,
                transactions: [Transaction]
            }
            type Wallet{
                _id: String,
                bankname: String,
                routingnumber: String,
                accountnumber: String,
                zipcode: String,
                creditcard: String,
                cvv: String,
                expmonth: String,
                expyear: String,
                amount: Float,
                type: String,
                username: String
            }
            type Transaction{
                _id: String,
                f_username: String,
                t_username: String,
                amount: Float,
                date: String,
                time: String
            }
            type Query{
                getUser(username: String): User
                getUsers: [User]
                getUserById(_id: String): User
            }
            type Mutation{
                createUser(username: String,
                    email: String,
                    ssn: String,
                    password: String,
                    fname: String,
                    lname: String) : User
                addFriend(username: String, friendusername: String): Friend
                addWallet(type: String, username: String): Wallet
                addTransaction(f_username: String, t_username: String, amount: Float, date: String, time : String): Transaction
                deleteFriend(username:String, friendusername: String): String
            }
            schema{
                query: Query
                mutation: Mutation
            }
        `]
        const resolvers = {
            Query: {
               getUser: async (root, {username}) => {
                    return prepare(await user.findOne({username: username}))
               },
               getUsers: async () => {
                   return (await user.find({}).toArray()).map(prepare)
               }
            },
            User: {
               friends: async ({username}) => {
                   return (await friend.find({username: username}).toArray()).map(prepare)
               },
               transactions: async ({username}) => {
                   return(await transaction.find({f_username: username}).toArray()).map(prepare)
               },
               wallet: async({username})=> {
                   return prepare(await wallet.findOne({username:username}))
               }
            },
            Friend:{
                transactions: async({username,friendusername})=>{
                    return (await transaction.find({f_username: username,t_username:friendusername}).toArray()).map(prepare)
                }
            },
            Mutation:{
                createUser: async (root, args)=>{
                    const res = await user.insert(args)
                    return prepare(await user.findOne(ObjectID(res.insertedIds[0])))
                },
                addFriend: async(root, args)=>{
                    const res = await friend.insert(args)
                    return prepare(await friend.findOne(ObjectID(res.insertedIds[0])))
                },
                addWallet: async(root,args)=>{
                    const res= await wallet.insert(args)
                    return prepare(await wallet.findOne(ObjectID(res.insertedIds[0])))
                },
                addTransaction: async(root,args)=>{
                    const res= await transaction.insert(args)
                    return prepare(await transaction.findOne(ObjectID(res.insertedIds[0])))
                },
                deleteFriend: async(root,args)=>{
                    const res=await friend.remove({username: args.username, friendusername: args.friendusername});
                    return "ok";
                }
            }
        }
        const schema = makeExecutableSchema({
            typeDefs,
            resolvers
        })
        const app = express()
        app.use("/graphql",bodyParser.json(), graphqlExpress({schema}))
        app.use("/graphiql", graphiqlExpress({
            endpointURL: "/graphql"
        }))

        app.listen(3000, function(err){
            if(err){
                console.log("ERROR")
            }
            console.log("LISTENING")
        })
    }
    catch(e){
        console.log(e)
    }
}