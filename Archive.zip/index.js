import 'babel-core/register'
import 'babel-polyfill'
import {start} from './app_gmodel'
start()